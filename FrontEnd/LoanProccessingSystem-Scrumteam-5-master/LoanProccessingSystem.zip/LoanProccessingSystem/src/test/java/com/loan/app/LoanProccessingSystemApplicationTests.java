package com.loan.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanProccessingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
