package com.loan.app.entities;

public enum Status {
 
	PENDING,
	
	APPROVED,
		
	WAITING_FOR_APPROVAL,	
	
	REJECTED,
		
	DOCUMENTS_NOT_UPLOADED,
		
	DOCUMENTS_UPLOADED


}
